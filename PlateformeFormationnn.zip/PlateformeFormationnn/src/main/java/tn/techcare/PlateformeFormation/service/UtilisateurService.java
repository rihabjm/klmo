package tn.techcare.PlateformeFormation.service;


import java.util.List;

import javax.validation.Valid;
import tn.techcare.PlateformeFormation.model.Utilisateur;

public interface UtilisateurService {
	
		Utilisateur findById(Long id);

		Utilisateur findByEmail(String email);

		List<Utilisateur> getAllUsers();

		Utilisateur getUserById(long id);

		void updateUser(@Valid Utilisateur user, long id);

		void deleteUser(long id);

		List<Utilisateur> getTypeUsers(String string);

		Utilisateur getUserByEmail(String email);

}
