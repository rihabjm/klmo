package tn.techcare.PlateformeFormation.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonIgnore;

import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Promotion;
import tn.techcare.PlateformeFormation.model.Salle;
import tn.techcare.PlateformeFormation.service.PromotionService;

@CrossOrigin("*")
@RestController
@RequestMapping("/promotion")
public class PromotionController {

	
	@Autowired
	private PromotionService promotionservice ;
	
 
	
	@GetMapping("/get")
	public List<Promotion>getAllpromotion()
	{
		return promotionservice.getAllPromotion();
		
	}
	
	@PostMapping("/add")
	public MessageReponse ajouterpromotion (@RequestBody Promotion promotion ){
	    
		return promotionservice.Ajouterpromotion(promotion);
	}
	
    @PutMapping("/update")
	private MessageReponse updatepromotion (@RequestBody Promotion  promotion ) {
		return promotionservice.Modifierpromotion(promotion);
		
	}

	@DeleteMapping("{id}")
	private MessageReponse deletpromotion (@PathVariable("id") Long id) {
		return promotionservice.Supprimerpromotion(id);
		
	}
	
	@GetMapping("/byid/{id}")
	private  Promotion getbyId(@PathVariable("id")Long  id) {
		return promotionservice.getpromotionbyId(id) ;
	
	}
}
