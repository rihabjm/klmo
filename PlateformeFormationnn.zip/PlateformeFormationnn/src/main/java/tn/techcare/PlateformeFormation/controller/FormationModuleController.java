package tn.techcare.PlateformeFormation.controller;

import java.io.ByteArrayOutputStream;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.zip.Deflater;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tn.techcare.PlateformeFormation.model.FormationModule;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.repository.FormationModuleRepository;
import tn.techcare.PlateformeFormation.service.FormationModuleService;


@CrossOrigin("*")
@RestController
@RequestMapping("/formationModule")
public class FormationModuleController {
	
	
	@Autowired
	private  FormationModuleService formationModuleService ;

	@Autowired
	private  FormationModuleRepository  formationModulerepository ;

	
	@PostMapping("/add")
	public FormationModule ajouterreunion (@RequestBody FormationModule formationmodule ) {
	   
		return formationModuleService.ajoutFormationModule(formationmodule);
	}
	
	@GetMapping("/get")
	public List<FormationModule>getAllFormation()
	{
		
     return formationModuleService.getAllFormation() ;
		
	}
	
	@PutMapping("/update")
	private MessageReponse updateformation (@RequestBody FormationModule  formation ) {
		return formationModuleService.updateFormation(formation) ;
		
	}

	@DeleteMapping("{id}")
	private MessageReponse deletformation (@PathVariable("id") Long id) {
		return formationModuleService.supprimerFormation(id) ;
		
	}
	  
	@GetMapping("/bytype/{type}")
	private List<FormationModule> getbytype(@PathVariable("type")String  type) {
		return formationModuleService.getformationbytype(type);
		
	}
	

	@GetMapping("/byintitule/{intitule}")
	private List<FormationModule> getbyintitule(@PathVariable("intitule")String  intitule) {
		return formationModuleService.getformationbyintitule(intitule) ;
		
	}
	


	@GetMapping("/byprix/{prix}")
	private List<FormationModule> getbyprix(@PathVariable("prix")float  prix) {
		return formationModuleService.getformationbyPrix(prix);
		
	}
	
	@GetMapping("/bynbrheure/{nombreheure}")
	private List<FormationModule> getbynombreheure(@PathVariable("nombreheure")int  nombreheure) {
		return formationModuleService.getformationbyNombreheure(nombreheure);
		
	}
	
	@GetMapping("/byid/{id}")
	private   Optional<FormationModule>  getbyId(@PathVariable("id") Long  id) {
		return formationModulerepository.findById(id)  ;
	
	}
  
	
	@GetMapping("/bysession/{session}")
	private List<FormationModule> getbynombreheure(@PathVariable("session")String  session) {
		return formationModuleService.getformationbySession(session);
		
	}
	
	   
}     
   