package tn.techcare.PlateformeFormation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Session;
import tn.techcare.PlateformeFormation.model.specialiite;
import tn.techcare.PlateformeFormation.service.SessionService;
import tn.techcare.PlateformeFormation.service.SpecialiteService;

@CrossOrigin("*")
@RestController
@RequestMapping("/Specialite")
public class SpecialiteController {
	@Autowired
	private  SpecialiteService specialiteservice ;
	
	
	@PostMapping("/add")
	public MessageReponse ajoutersession (@RequestBody specialiite  specialite ){
	    
		return specialiteservice.AjouterSpecialite(specialite);
	}
	
	@GetMapping("/get")
	public List<specialiite>getAllSpecialite()
	{
		
     return specialiteservice.getAllSpecilite();
		
	}
	
	@GetMapping("/byid/{id}")
	private specialiite getbyid(@PathVariable("id")Long  id) {
		return specialiteservice.getspecialiteById(id) ;

	}

	    
	@GetMapping("/bycategorie/{categorie}")
	private List<Formateur> getbynomspecialite(@PathVariable("categorie")  String  categorie) {
		return specialiteservice.getcategorieFormation(categorie);

	}
	   
	
}
