package tn.techcare.PlateformeFormation.model;


import static org.junit.Assert.assertFalse;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;

import javax.persistence.OneToMany;
import javax.persistence.Table;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import ch.qos.logback.core.joran.action.Action;

@Entity
@Table(name = "Specialite")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class specialiite {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private Long idspecialite ;
	private String  nomspecialite ;
	
	
	  @JsonIgnore
	  @OneToMany(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
	 @JsonIgnoreProperties(value = {"certificat"}, allowSetters = true)
	    @JoinColumn(name = "idspecialite", nullable = false )
   private List<Certificat> certificats ;
	    
	@JsonIgnore
	 @ManyToMany(mappedBy = "specialites" ,fetch = FetchType.EAGER)
	    private List<Formateur> Formateurs = new ArrayList<>();
	 
	public Long getIdspecialite() {
		return idspecialite;
		
		
		
	}   
	public void setIdspecialite(Long idspecialite) {
		this.idspecialite = idspecialite;
	}
	public String getNomspecialite() {
		return nomspecialite;
	}
	public void setNomspecialite(String nomspecialite) {
		this.nomspecialite = nomspecialite;
	}	
	

	public List<Certificat> getCertificats() {
		return certificats;   
	}
	public void setCertificats(List<Certificat> certificats) {
		this.certificats = certificats;
	}
	public Collection<Formateur> getFormateurs() {
		return Formateurs;
	}
	public void setFormateurs(List<Formateur> formateurs) {
		Formateurs = formateurs;
	}
	   
	
}  
