package tn.techcare.PlateformeFormation.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import tn.techcare.PlateformeFormation.model.Programmekhademni;

@Repository
public interface ProgrammekhademniRepository  extends JpaRepository<Programmekhademni,Long> {
	Programmekhademni findProgrammekhademniByIdformation(Long id ) ;
	   List<Programmekhademni> findProgrammekhademniByType(String type ) ;
       List<Programmekhademni> findProgrammekhademniByIntitule(String intitule ) ;
	   List<Programmekhademni> findProgrammekhademnieByPrix(float prix ) ;
}
       