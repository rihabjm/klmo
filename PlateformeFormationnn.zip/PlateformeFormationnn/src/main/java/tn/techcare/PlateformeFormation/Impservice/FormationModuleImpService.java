package tn.techcare.PlateformeFormation.Impservice;


import java.util.ArrayList;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tn.techcare.PlateformeFormation.model.FormationModule;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.repository.FormateurRepository;
import tn.techcare.PlateformeFormation.repository.FormationModuleRepository;
import tn.techcare.PlateformeFormation.service.FormationModuleService;
@Service
@Transactional
public class FormationModuleImpService implements FormationModuleService  {
	@Autowired
	private FormationModuleRepository formationmoduleRepository ;

	@Autowired
	private FormateurRepository formateurrepository ;
	 
	@Transactional
	@Override
	public FormationModule ajoutFormationModule(FormationModule formation) {
		
      formationmoduleRepository.save(formation);
		return formation ;
	}


	@Override
	public List<FormationModule> getAllFormation() {
		return formationmoduleRepository.findAll();
	}


	@Override
	public MessageReponse updateFormation(FormationModule formation) {
		FormationModule	 module = formationmoduleRepository.findById(formation.getIdformation()).orElse(null) ;
		if(module== null) {
		return new MessageReponse(false, "erreur , formation  introuvable");
		}
		formationmoduleRepository.save(formation);
		return new MessageReponse(true, "operation modifier effectue avec succes");
	}


	@Override
	public MessageReponse supprimerFormation(Long id) {
		FormationModule module = formationmoduleRepository.findById(id).orElse(null) ;
		if(module== null) {
		return new MessageReponse(false, "erreur , formation  introuvable");
		}
		formationmoduleRepository.delete(module);
		return new MessageReponse(true, "operation delet effectue avec succes");
	}


	@Override
	public List<FormationModule> getformationbytype(String type) {
		// TODO Auto-generated method stub
	
	
	     List<FormationModule> list =new ArrayList(); 
	     list =formationmoduleRepository.findFormationModuleByType(type) ;
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
		
		
		
	}





	@Override
	public List<FormationModule> getformationbyintitule(String intitule) {
		// TODO Auto-generated method stub
	
		
	     List<FormationModule> list =new ArrayList(); 
	     list =formationmoduleRepository.findFormationModuleByIntitule(intitule) ;
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
		
	}





	@Override
	public List<FormationModule> getformationbyPrix(float prix) {
		// TODO Auto-generated method stub
		
	     List<FormationModule> list =new ArrayList(); 
	     list =formationmoduleRepository.findFormationModuleByPrix(prix);
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
	}


	@Override
	public List<FormationModule> getformationbyNombreheure(int nbr) {
		// TODO Auto-generated method stub
	  List<FormationModule> list =new ArrayList(); 
	     list =formationmoduleRepository.findFormationModuleByNombreheure(nbr);
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
	}


	@Override
	public List<FormationModule> getformationbySession(String session) {
		// TODO Auto-generated method stub
		  List<FormationModule> list =new ArrayList(); 
		     list =formationmoduleRepository.findFormationModuleBySession(session);
			
			if (list ==null ) {
				System.out.println("");

			}
			return list ;
	}


	@Override
	public FormationModule getformationbyId(Long id) {
		// TODO Auto-generated method stub
		return  formationmoduleRepository.findFormationModuleByIdformation(id) ;
	}


	


}
