package tn.techcare.PlateformeFormation.security;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.Utilisateur;
import tn.techcare.PlateformeFormation.service.AccountService;

import java.util.ArrayList;
import java.util.Collection;
@Service
public class UserDetailsServiceImpl implements UserDetailsService  {
 
	@Autowired
    private AccountService accountService ;
    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        System.out.println("load loula");
        Utilisateur user = accountService.loadUserByEmail(email);
        System.out.println("load thenia");
        if(user==null)
        
        { System.out.println ("email not exist");}
        System.out.println("load theltha");
        Collection<GrantedAuthority> authorities = new ArrayList<>() ;
        System.out.println("load rabeaa");
     authorities.add(new SimpleGrantedAuthority(user.getRole().getRoleName()));
        System.out.println("maoujoud");
        return new org.springframework.security.core.userdetails.User(user.getLogin(),user.getMdp(),authorities);
    }
}
