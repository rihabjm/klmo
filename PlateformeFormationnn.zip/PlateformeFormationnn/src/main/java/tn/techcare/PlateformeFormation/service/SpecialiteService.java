package tn.techcare.PlateformeFormation.service;

import java.util.List;

import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.specialiite;

public interface SpecialiteService {
    public MessageReponse AjouterSpecialite (specialiite specialite) ;
	   public List<specialiite> getAllSpecilite();
	   
	   public  specialiite getspecialiteById(long id) ;
	   
	   public  List<specialiite>getSpeciliteByformateur(long id) ;
	   
	   public  List<Formateur>getcategorieFormation(String cateogrie ) ;
	   
}
   