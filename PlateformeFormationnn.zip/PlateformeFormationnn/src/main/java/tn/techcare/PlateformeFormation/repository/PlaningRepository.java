package tn.techcare.PlateformeFormation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import tn.techcare.PlateformeFormation.model.Planing;

@Repository
public interface PlaningRepository extends JpaRepository<Planing,Integer> {

}  
