package tn.techcare.PlateformeFormation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Session;
import tn.techcare.PlateformeFormation.model.fraispayement;
import tn.techcare.PlateformeFormation.service.fraixpayementService;

@CrossOrigin("*")
@RestController
@RequestMapping("/fraix")
public class FraixController {
	
	@Autowired
	private  fraixpayementService    fraixservice ;
	
	@PutMapping("/update")
	private MessageReponse updateformation (@RequestBody fraispayement fraix ) {
		return fraixservice.modifier(fraix) ;
		
	}


	@PostMapping("/add/{idCategory}/{id}")
	public MessageReponse ajouterfraix (@RequestBody fraispayement fraix ,@PathVariable("idCategory")long  idsession ,@PathVariable("id") long idformateur){
	    
		return fraixservice.Ajouterfraix(fraix, idsession, idformateur) ;
	}
	
	@GetMapping("/byidsession/{id}")
	private  List<Formateur> getbyIdsession(@PathVariable("id")Long  idsession) {
		return  fraixservice.getfraixbysession(idsession) ;
	
	}
	
	@GetMapping("/byformateur/{id}")
	private  List<fraispayement> getbyIdformateur(@PathVariable("id")Long  idformateur) {
		return  fraixservice.getfraixbyformateur(idformateur);
	
	}

	@GetMapping("/byformateursession/{id}/{idsession}")
	private  fraispayement getbyIdformateursession(@PathVariable("id")Long  idformateur ,@PathVariable("idsession")Long  idsession ) {
		return  fraixservice.getfraixbyformateursession(idsession, idformateur);
	
	}	
 
	@GetMapping("/getsessionformateur/{idformateur}")
	private  List<Session> getSessionformateur(@PathVariable("id")Long  idformateur ) {
		return  fraixservice.getsessionfromateur(idformateur) ;
	   
	}	
	
	
}
