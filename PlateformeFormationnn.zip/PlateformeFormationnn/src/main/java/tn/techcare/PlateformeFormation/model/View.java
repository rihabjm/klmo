package tn.techcare.PlateformeFormation.model;

public class View {

	  public interface FileInfo {}
}
