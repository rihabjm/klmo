package tn.techcare.PlateformeFormation.model;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "Session")
public class Session {

		public Session() {}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private Long idsession ;
	 private String  designationsession ;
	private Date  datedebut ; 
	private Date datefin ;
	private String etat ;
	private int nombrepartcipant ;
	
	@JsonIgnore
	@OneToMany(mappedBy = "session", cascade = {CascadeType.ALL})
	private List<Remise> remises ;
	
	@JsonIgnore
	@OneToMany(mappedBy = "session", cascade = {CascadeType.ALL})
	private List<Planing> planing ;
	
	
	   @JsonIgnore
		@OneToMany(mappedBy = "session", cascade = {CascadeType.ALL})
		private List<fraispayement> fraix ;
	
	@ManyToMany
	@JoinTable(
	           name="InscrirSession")
	private List<Inscrir> inscrirs;


	
	 @JsonIgnore
	    @ManyToOne(cascade = CascadeType.MERGE)
	    @JoinColumn(name = "idformation")
	    private Formation formation  ;
	 
	 
	 
	public int getNombrepartcipant() {
		return nombrepartcipant;
	}

	public void setNombrepartcipant(int nombrepartcipant) {
		this.nombrepartcipant = nombrepartcipant;
	}


	public Long getIdsession() {
		return idsession;
	}


	public void setIdsession(Long idsession) {
		this.idsession = idsession;
	}

	public Date getDatedebut() {
		return datedebut;
	}

	public void setDatedebut(Date datedebut) {
		this.datedebut = datedebut;
	}

	public Date getDatefin() {
		return datefin;
	}

	public void setDatefin(Date datefin) {
		this.datefin = datefin;
	}


	public Formation getFormation() {
		return formation;
	}

	public void setFormation(Formation formation) {
		this.formation = formation;
	}


  public List<Inscrir> getInscrirs() {
		return inscrirs;
	}

	public void setInscrirs(List<Inscrir> inscrirs) {
		this.inscrirs = inscrirs;
	}

	public List<fraispayement> getFraix() {
		return fraix;
	}

	public void setFraix(List<fraispayement> fraix) {
		this.fraix = fraix;
	}

	public List<Remise> getRemises() {
		return remises;
	}

	public void setRemises(List<Remise> remises) {
		this.remises = remises;
	}

	public String getEtat() {
		return etat;
	}

	public void setEtat(String etat) {
		this.etat = etat;
	}

	public List<Planing> getPlaning() {
		return planing;
	}

	public void setPlaning(List<Planing> planing) {
		this.planing = planing;
	}

   	
}
