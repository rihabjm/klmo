package tn.techcare.PlateformeFormation.service;

import java.util.List;

import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Promotion;
import tn.techcare.PlateformeFormation.model.Salle;


public interface PromotionService {

	  public MessageReponse Ajouterpromotion (Promotion promotion) ;
	  public List<Promotion>getAllPromotion();
	  public MessageReponse Modifierpromotion(Promotion promotion) ;
	  public MessageReponse Supprimerpromotion(Long idsalle);

	public Promotion getpromotionbyId(Long id);
	  
}
