package tn.techcare.PlateformeFormation.controller;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.FormationModule;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Programmekhademni;
import tn.techcare.PlateformeFormation.service.ProgrammekhademniService;

@CrossOrigin("*")
@RestController
@RequestMapping("/programmekhademni")
public class ProgrammekhademniController {
	@Autowired
	private   ProgrammekhademniService KhademniService ;
	
	@PostMapping("/add")
	private MessageReponse AjouterKhademni (@RequestBody Programmekhademni Khademni) {
		return KhademniService.ajoutFormation(Khademni) ;
	}
	
  @GetMapping("/get")
  private List<Programmekhademni> getallkhademni()
  {
	  return KhademniService.getAllFormation();
  }
  

@PutMapping("/update")
private MessageReponse Modifierkhademni (@RequestBody Programmekhademni khademni ) {
	return KhademniService.updateformation(khademni);
	
}


@DeleteMapping("{id}")
private MessageReponse Supprimerkhademni (@PathVariable("id") long id) {
	return KhademniService.supprimerFormation(id) ;
	
}

@GetMapping("/byid/{id}")
private   Programmekhademni getbyId(@PathVariable("id") Long  id) {
	return  KhademniService.getformationbyId(id)  ;

}



@GetMapping("/bytype/{type}")
private List<Programmekhademni> getbytype(@PathVariable("type")String  type) {
	return KhademniService.getformationbytype(type);
	
}



@GetMapping("/byintitule/{intitule}")
private List<Programmekhademni> getbyintitule(@PathVariable("intitule")String  intitule) {
	return KhademniService.getformationbyintitule(intitule);
	
}


@GetMapping("/byprix/{prix}")
private List<Programmekhademni> getbyprix(@PathVariable("prix")float  prix) {
	return KhademniService.getformationbyPrix(prix);
	
}


}
