package tn.techcare.PlateformeFormation.service;

import java.util.Date;
import java.util.List;

import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Planing;
import tn.techcare.PlateformeFormation.model.Salle;
import tn.techcare.PlateformeFormation.model.Seance;
import tn.techcare.PlateformeFormation.model.Session;
public interface PlaningService {
    public MessageReponse Ajouterplaning (Planing planing,  Long  idsession ,int idseance ,Long idsalle ) ;
   public List<Planing> getplaningbysession(long idsession ); 
   public List<String> getFormateurPlanningParrJour(String date , Long idformateur ,long idsenace );
   public boolean getsalleoccupee(String date ,long idseance,long idsalle ) ;
   
}   
     