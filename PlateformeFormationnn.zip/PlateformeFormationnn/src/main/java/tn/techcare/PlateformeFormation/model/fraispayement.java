package tn.techcare.PlateformeFormation.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
@Table(name = "fraispayement")
public class fraispayement {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idfraix;
	public float salaire ;
	public  int nombreheure ;
	public float avance ;
	
	 @JsonIgnore
	    @ManyToOne(cascade = CascadeType.MERGE)
	    @JoinColumn(name = "idsession")
	    private Session session  ;
	 
	 @JsonIgnore
	    @ManyToOne(cascade = CascadeType.MERGE)
	    @JoinColumn(name = "idformateur")
	    private Formateur formateur  ;  
	
	public Long getIdfraix() {
		return idfraix;
	}
	public void setIdfraix(Long idfraix) {
		this.idfraix = idfraix;
	}
	public float getSalaire() {
		return salaire;
	}
	public void setSalaire(float salaire) {
		this.salaire = salaire;
	}
	public int getNombreheure() {
		return nombreheure;
	}
	public void setNombreheure(int nombreheure) {
		this.nombreheure = nombreheure;
	}
	public float getAvance() {
		return avance;
	}
	public void setAvance(float avance) {
		this.avance = avance;
	}
	public Session getSession() {
		return session;
	}
	public void setSession(Session session) {
		this.session = session;
	}
	public Formateur getFormateur() {
		return formateur;
	}
	public void setFormateur(Formateur formateur) {
		this.formateur = formateur;
	}

	
  
}
