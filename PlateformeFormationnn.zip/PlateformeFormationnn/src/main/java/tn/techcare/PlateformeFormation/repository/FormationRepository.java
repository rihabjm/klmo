package tn.techcare.PlateformeFormation.repository;




import java.sql.Date;
import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import tn.techcare.PlateformeFormation.model.Formation;


@Repository
public interface FormationRepository extends JpaRepository<Formation, Long> {
	List<Formation> findFormationByIntitule(String intitule ) ;
	Formation findFormationByIdformation(Long id ) ;

	
	List<Formation> findFormationByType(String type ) ;
	
	List<Formation> findFormationByPrix(float prix ) ; 

}
