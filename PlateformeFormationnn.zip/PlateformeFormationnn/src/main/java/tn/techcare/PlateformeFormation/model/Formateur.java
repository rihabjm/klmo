package tn.techcare.PlateformeFormation.model;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

   
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

 
@Entity
@Table(name = "formateur")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Formateur  extends Utilisateur {
 

	@JsonIgnore
 @ManyToMany(fetch = FetchType.EAGER)
 @JoinTable(
		  name = "utilisateur_specialites", 
		  joinColumns = @JoinColumn(name = "formateur_id"),  
		  inverseJoinColumns = @JoinColumn(name = "specialites_idspecialite"))
 private List<specialiite> specialites = new ArrayList<>();

	  
	
	    
	   @JsonIgnore
			@OneToMany(mappedBy = "formateur", cascade = {CascadeType.ALL})
			private List<fraispayement> fraix ;
			
			
			
			@JsonIgnore
	  @OneToOne(fetch = FetchType.LAZY,
			  cascade = {CascadeType.ALL},
	            mappedBy = "formateur")
	    private CV cv;
	  

	    
	   

	public Collection<specialiite> getSpecialites() {
		return specialites;
	}

	public void setSpecialites(List<specialiite> specialites) {
		this.specialites = specialites;
	}

	public void setCv(CV cv) {
		this.cv = cv;
	}



	public List<fraispayement> getFraix() {
		return fraix;
	}

	public void setFraix(List<fraispayement> fraix) {
		this.fraix = fraix;
	}

 

	public CV getCv() {
		return cv;
	}

	public Formateur() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Formateur(Long id, String nom, String prenom, String adresse, int telephone, String login, String mdp,
			Date dateNAisse, String sexe, String gmail, String facebook, String linked,List<specialiite> specialites, List<fraispayement> fraix,
			CV cv) {
		super(id, nom, prenom, adresse, telephone, login, mdp, dateNAisse, sexe, gmail, facebook, linked);
		this.specialites = specialites;  
	   
		this.fraix = fraix;
		this.cv = cv;
	}

	   




	
}
