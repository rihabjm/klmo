package tn.techcare.PlateformeFormation.Impservice;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Promotion;
import tn.techcare.PlateformeFormation.model.Salle;
import tn.techcare.PlateformeFormation.model.specialiite;
import tn.techcare.PlateformeFormation.repository.PromotionRepository;
import tn.techcare.PlateformeFormation.service.PromotionService;

@Service
@Transactional
public class PromotionImpService implements PromotionService {

	@Autowired
	private PromotionRepository promotionrepository ;
	
	
	@Override
	public List<Promotion> getAllPromotion() {
		// TODO Auto-generated method stub
		return promotionrepository.findAll();
		}





	@Override
	public MessageReponse Ajouterpromotion(Promotion promotion) {
		// TODO Auto-generated method stub
		promotionrepository.save(promotion);
			 return new MessageReponse(true, promotion.getIdpromotion()+ "promotion est ajouter ") ;
	}


	@Override
	public MessageReponse Modifierpromotion(Promotion promotion) {
		// TODO Auto-generated method stub
		Promotion	 promotion1 = promotionrepository.findById(promotion.getIdpromotion()).orElse(null) ;
		if(promotion1== null) {
		return new MessageReponse(false, "erreur , promotion  introuvable");
		}
		promotionrepository.save(promotion);
		return new MessageReponse(true, "operation modifier effectue avec succes");
	}


	@Override
	public MessageReponse Supprimerpromotion(Long idpromotion) {
		// TODO Auto-generated method stub
		Promotion	 promotion1 = promotionrepository.findPromotionByIdpromotion(idpromotion) ;
		if(promotion1== null) {
		return new MessageReponse(false, "erreur , promotion  introuvable");
		}
		promotionrepository.delete(promotion1);
		return new MessageReponse(true, "operation delet  effectue avec succes");	}


	@Override
	public Promotion getpromotionbyId(Long id) {
		// TODO Auto-generated method stub
		return promotionrepository.findPromotionByIdpromotion(id);
	}

}
