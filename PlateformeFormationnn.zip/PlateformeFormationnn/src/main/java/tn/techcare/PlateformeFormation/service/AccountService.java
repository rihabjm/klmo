package tn.techcare.PlateformeFormation.service;

import tn.techcare.PlateformeFormation.model.Role;
import tn.techcare.PlateformeFormation.model.Utilisateur;

public interface AccountService {
	  public Utilisateur saveUser (Utilisateur user) ;
	  public Utilisateur saveUserFormateur (Utilisateur user) ;
	  public Utilisateur saveUserParticipant (Utilisateur user) ;
	  public Utilisateur saveUsergestionnaire (Utilisateur user) ;
	  public Role saveRole (Role role) ;
	 public    Utilisateur loadUserByEmail ( String email) ;
	  public   void addRoleToUser (String Email , String roleName) ;
}
