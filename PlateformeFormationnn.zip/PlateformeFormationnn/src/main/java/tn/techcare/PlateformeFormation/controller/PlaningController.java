package tn.techcare.PlateformeFormation.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Planing;
import tn.techcare.PlateformeFormation.model.Remise;
import tn.techcare.PlateformeFormation.model.Salle;
import tn.techcare.PlateformeFormation.model.Session;
import tn.techcare.PlateformeFormation.service.PlaningService;

@CrossOrigin("*")
@RestController
@RequestMapping("/planing")
public class PlaningController {

	@Autowired 
	private PlaningService planingservice ;
	
	@PostMapping("/add/{idCategory}/{id}/{idsalle}")
	public MessageReponse ajouterpalning (@RequestBody Planing  planing ,@PathVariable("idCategory")long  idsession ,@PathVariable("id") int idseance,@PathVariable("idsalle")long  idsalle){
	    
		return planingservice.Ajouterplaning(planing, idsession, idseance, idsalle) ;
	}
	    
	@GetMapping("/bysession/{idsession}")
	private  List<Planing> getbyidpromotion(@PathVariable("idsession")long  idsession) {
		return planingservice.getplaningbysession(idsession) ;

	}  
	    
    
	@GetMapping("/getsalleoccupe/{date}/{idseance}/{idsalle}")
	private boolean getbyidpromotion(@PathVariable("date")String date ,@PathVariable("idseance")long  idseance,@PathVariable("idsalle")long  idsalle) {
		return planingservice.getsalleoccupee(date, idseance,idsalle) ;
    }        
 	 
	@GetMapping("/getplaningseance/{date}/{idformateur}/{idseance}")
	private List<String> getplaningbyseance(@PathVariable("date")String date ,@PathVariable("idformateur")long  idformateur ,@PathVariable("idseance")long  idseance) {
		return planingservice.getFormateurPlanningParrJour(date, idformateur,idseance) ; 
  
	}        
 	        
	  
	
}
