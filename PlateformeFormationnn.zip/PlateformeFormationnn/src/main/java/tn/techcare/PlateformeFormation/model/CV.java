package tn.techcare.PlateformeFormation.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "cv")
public class CV extends  FileModel {
	   @JsonIgnore
	  @OneToOne(fetch = FetchType.LAZY ,cascade = CascadeType.MERGE)
	    @OnDelete(action = OnDeleteAction.CASCADE)
      @JoinColumn(name = "idformateur", nullable = false)
    private Formateur formateur;

	public Formateur getFormateur() {
		return formateur;
	}

	public void setFormateur(Formateur formateur) {
		this.formateur = formateur;
	}

	public CV() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CV(String name, String mimetype, byte[] pic) {
		super(name, mimetype, pic);
		// TODO Auto-generated constructor stub
	}
  
	
	
	
}
