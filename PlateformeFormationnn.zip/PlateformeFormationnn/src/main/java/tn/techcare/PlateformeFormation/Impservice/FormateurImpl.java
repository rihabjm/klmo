package tn.techcare.PlateformeFormation.Impservice;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.entites.MessageResponse;
import tn.techcare.PlateformeFormation.entites.MyConstants;
import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Utilisateur;
import tn.techcare.PlateformeFormation.model.fraispayement;
import tn.techcare.PlateformeFormation.model.specialiite;
import tn.techcare.PlateformeFormation.repository.FormateurRepository;
import tn.techcare.PlateformeFormation.repository.SpecialiteRepository;
import tn.techcare.PlateformeFormation.repository.UtilisateurRepository;
import tn.techcare.PlateformeFormation.repository.fraixpayementRepository;
import tn.techcare.PlateformeFormation.service.FormateurService;
import java.time.Period;  
   
@Component
@Service
@Transactional
public class FormateurImpl  implements FormateurService{
 
	@Autowired
	private fraixpayementRepository fraixpayement ;
	
  @Autowired
	  private  FormateurRepository fromateurRepository ;
	@Autowired
	  private  UtilisateurRepository utilisateurrepository ;

	
	@Autowired
	private SpecialiteRepository specalitrepository ;
	
	@Autowired
	public JavaMailSender emailSender;
	
	@Transactional
	@Override
	public Formateur AjoutFormateur(Formateur formateur) {
	
		// TODO Auto-generated method stub
	fromateurRepository.save(formateur);

		return  formateur ;
	}

	
	
	@Override
	public List<Formateur> getAllFormateur() {
		// TODO Auto-generated method stub
		return (List<Formateur>) fromateurRepository.findAll();

	}
	@Transactional
	@Override
	public MessageReponse ModifierFormateur(Formateur formateur) {
		// TODO Auto-generated method stub
		
		Formateur formateur2 = fromateurRepository.findById(formateur.getId()).orElse(null);
		System.out.println(formateur2.getId());	

		if (formateur2!=null) 
		{
			fromateurRepository.save(formateur);
	           return new MessageReponse(true, "formateur modifiée");
		}
		       return new MessageReponse(false , "formateur introuvable");
	    }
	@Override
	public MessageReponse SupprimerFormateur(Long id) {
		// TODO Auto-generated method stub
		Formateur formateur2 = fromateurRepository.findById(id).orElse(null) ;
	       if(formateur2== null) 
	       {
	       return new MessageReponse(false, "erreur , formateur introuvable");
	       }
	       fromateurRepository.delete(formateur2);
	         return new MessageReponse(true, "operation delet effectue avec succes");

	       }

	@Override
	public List<Formateur> getFormateurByNom(String nom) {
		// TODO Auto-generated method stub
	
		
	     List<Formateur> list =new ArrayList(); 
	     list =fromateurRepository.findFormateurByNom(nom);
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
		
	}

	@Override
	public List<Formateur> getFormateurByPrenom(String prenom) {
		// TODO Auto-generated method stub
	
		 List<Formateur> list =new ArrayList(); 
	     list =fromateurRepository.findFormateurByPrenom(prenom);
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
	}

	@Override
	public List<Formateur> getFormateurByAdresse(String adresse) {
		// TODO Auto-generated method stub

		 List<Formateur> list =new ArrayList(); 
	     list =fromateurRepository.findFormateurByAdresse(adresse);
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
	}

	@Override
	public List<Formateur> getFormateurByMail(String mail) {
		// TODO Auto-generated method stub
		 List<Formateur> list =new ArrayList(); 
	     list =fromateurRepository.findFormateurByGmail(mail);
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
	}

	@Override
	public List<Formateur> getFormateurByTelephone(int telephone) {
		// TODO Auto-generated method stub
		 List<Formateur> list =new ArrayList(); 
	     list =fromateurRepository.findFormateurByTelephone(telephone) ;
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
		
	}

	@Override
	public List<Formateur> getFormateurByDateNAisse(Date datenais) {
		// TODO Auto-generated method stub
		
		 List<Formateur> list =new ArrayList(); 
	     list =fromateurRepository.findFormateurByDateNAisse(datenais);
		
		if (list ==null ) {
			System.out.println("");
    }
		return list ;
			}

	@Override
	public Formateur getFormateurById(Long id) {
	
		  
		Formateur formateur =fromateurRepository.findFormateurById(id) ;
		
		if (formateur ==null ) {
			System.out.println("");

		}
		return formateur ;
		
		
	}
	@Transactional
	@Override
	public MessageResponse save(Formateur formateur) {
		
	 
			Utilisateur list = utilisateurrepository.findByLoginAndId(formateur.getLogin(), formateur.getId());
			if (list == null) {
				list = utilisateurrepository.findByLogin(formateur.getLogin());
				if (list != null) {
					return new MessageResponse(false, "Email existant");
				}
			}

			
		
		
		fromateurRepository.save(formateur);

			return new MessageResponse(true, "Op�ration effectu�e avec succ�s");
		 
		
		
	}



	
	@Override
	public Formateur affectspecilite(long idsp ,Long idformateur) {
	 	// TODO Auto-generated method stub
		
	 specialiite specialite =specalitrepository.findByIdspecialite(idsp) ;
		 Formateur formateur =fromateurRepository.findFormateurById(idformateur);
	formateur.getSpecialites().add(specialite); 
			 
 fromateurRepository.save(formateur);
		 
	return formateur;
}
@Override
	public List<specialiite> getSpecialite(long id) {
		// TODO Auto-generated method stub
		 List<Formateur> formateurs =fromateurRepository.findAll() ;
		 List<specialiite> specialites =new ArrayList<specialiite>();
		for(int i=0 ;i<formateurs.size() ;i++)
		{
			if(formateurs.get(i).getId()==0)  
			{
				
				specialites=(List<specialiite>) formateurs.get(i).getSpecialites();
			}
		}
		    
		return specialites;
	}



@Override
public List<Formateur> getFormateurbyspecialite(String specialite) {
	// TODO Auto-generated method stub
	
	 List<Formateur> formateurs =fromateurRepository.findAll() ;
	 List<Formateur> formateursspecialite =new ArrayList<Formateur>() ;
		for(int i=0 ;i<formateurs.size() ;i++)
			
		{  
			List<specialiite> specialites =(List<specialiite>) formateurs.get(i).getSpecialites() ;
			for(int j=0 ;j<specialites.size() ;i++)
		{
			if(specialites.get(j).getNomspecialite().contains(specialite))
			{
				formateursspecialite.add(formateurs.get(i));
				
			}}}
	 
	return formateursspecialite;
}



@Override
public List<String> getjouroccupee(long idformateur) {
	// TODO Auto-generated method stub
	List<fraispayement> fraix = fraixpayement.findAll() ;  
       
  List<LocalDate>jouroccuppe =new ArrayList<LocalDate>();
  List<String>Listjouroccuppe =new ArrayList<String>();
	     
for(int i=0 ;i<fraix.size();i++)
{
if(fraix.get(i).getFormateur().getId()==idformateur)
{

  
     Period period = Period.between(fraix.get(i).getSession().getDatedebut().toLocalDate(), fraix.get(i).getSession().getDatefin().toLocalDate());
  
		   	int dureejour =period.getDays() ;
			int dureemois =period.getMonths()*30 ;	
	     int duree=dureejour+dureemois+1 ;
for(int s=0  ;s<=duree ;s++)   
{    
	Listjouroccuppe.add(fraix.get(i).getSession().getDatedebut().toLocalDate().plusDays(s).toString()) ;

}        

}}	         
	   
	System.out.print(Listjouroccuppe);
	return Listjouroccuppe;
}

}



	
     