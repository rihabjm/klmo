package tn.techcare.PlateformeFormation.Impservice;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Salle;
import tn.techcare.PlateformeFormation.model.Seance;
import tn.techcare.PlateformeFormation.model.Session;
import tn.techcare.PlateformeFormation.repository.SalleRepository;
import tn.techcare.PlateformeFormation.repository.SeanceRepository;
import tn.techcare.PlateformeFormation.repository.SessionRepository;
import tn.techcare.PlateformeFormation.service.SeanceService;

@Service
@Transactional
public class SeanceImpService implements SeanceService {

	@Autowired
	private SeanceRepository  seancerepoistory;
	@Autowired
	private SalleRepository  sallerepoistory;
	@Autowired
	private SessionRepository  sessionrepoistory;
	
	/*	Formateur formateur2 = fromateurRepository.findById(formateur.getId()).orElse(null);
		System.out.println(formateur2.getId());	

		if (formateur2!=null) 
		{
			fromateurRepository.save(formateur);
	           return new MessageReponse(true, "formateur modifiée");
		}
		       return new MessageReponse(false , "formateur introuvable");
	    }*/
	

	@Override
	public List<Seance> getAllSeance() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public MessageReponse ModifierSeance(Seance senace) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public MessageReponse SupprimerSession(Long idsenace) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Seance> getAllSeancebysession(long idsession) {
		List<Seance> seances =seancerepoistory.findAll();
		List<Seance> seancessession =new ArrayList<Seance>();
	/*	  for(int i=0 ;i<seances.size();i++)
		 {
			  if(seances.get(i).getSession().getIdsession()==idsession)
			  {
				  seancessession.add(seances.get(i));
				  
			  }
			  
			  
		  }*/
		return seancessession;
	}
	


}
