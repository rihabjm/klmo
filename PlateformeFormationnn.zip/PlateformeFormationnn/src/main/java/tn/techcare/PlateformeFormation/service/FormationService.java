package tn.techcare.PlateformeFormation.service;

import java.util.Date;
import java.util.List;

import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.MessageReponse;

public interface FormationService  {

   public MessageReponse ajoutFormation (Formation formation) ;
   public List<Formation> getAllFormation();
   public List<Formation> getformationbyintitule(String intitule ) ;
   public MessageReponse updateformation(Formation formation );
   public Formation getformationbyId(Long id);
   public MessageReponse supprimerFormation(Long id);
	public List<Formation> getformationbytype(String type ) ;

	public List<Formation> getformationbyPrix(float prix ) ;
}
