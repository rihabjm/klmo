package tn.techcare.PlateformeFormation.Impservice;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.annotation.JsonIgnore;

import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Session;
import tn.techcare.PlateformeFormation.model.fraispayement;
import tn.techcare.PlateformeFormation.repository.FormateurRepository;
import tn.techcare.PlateformeFormation.repository.SessionRepository;
import tn.techcare.PlateformeFormation.repository.fraixpayementRepository;
import tn.techcare.PlateformeFormation.service.fraixpayementService;

@Service
public class fraixpayementImpService implements fraixpayementService {
   
	@Autowired
	private fraixpayementRepository fraixrepoistory;
	
	@Autowired
	private SessionRepository sessionrepository ;
	 
	@Autowired
	private FormateurRepository formateurrepository ;
	
	@JsonIgnore
	@Override
	public MessageReponse Ajouterfraix(fraispayement fraix, Long idsession, Long idformateur) {
		// TODO Auto-generated method stub
		Optional<Session> s= sessionrepository.findById(idsession);
		Optional<Formateur> f =formateurrepository.findById(idformateur);
		fraix.setFormateur(f.get());
		fraix.setSession(s.get());
	 fraixrepoistory.save(fraix);
	 return new MessageReponse(true , "") ;
	}

   
	@Override
	public List<Formateur> getfraixbysession(long idsession) {
		// TODO Auto-generated method stub
		
		List<Formateur> listfraix =new ArrayList<Formateur>();
		List<fraispayement> listfr = fraixrepoistory.findAll() ;
		for(int i=0 ;i<listfr.size() ;i++)
		{
			if(listfr.get(i).getSession().getIdsession()==idsession)
			{
				listfraix.add(listfr.get(i).getFormateur());
			}	
			
		}
		
		
		return listfraix;
	}


	@Override
	public List<fraispayement> getfraixbyformateur(long idformateur) {
		// TODO Auto-generated method stub
		List<fraispayement> listfraix =new ArrayList<fraispayement>();
		List<fraispayement> listfr = fraixrepoistory.findAll() ;
		for(int i=0 ;i<listfr.size() ;i++)
		{
			if(listfr.get(i).getFormateur().getId()==idformateur)
			{
				listfraix.add(listfr.get(i));
			}	
			
		}
		
		
		return listfraix;
	}


	@Override
	public fraispayement getfraixbyformateursession(Long idsession, Long idformateur) {
		// TODO Auto-generated method stub
		  
		fraispayement fraix= new fraispayement();
		
		List<fraispayement> listfr = fraixrepoistory.findAll() ;
		for(int i=0 ;i<listfr.size() ;i++)
		{
			if((listfr.get(i).getFormateur().getId()==idformateur ) &&(listfr.get(i).getSession().getIdsession()==idsession))
			{
				fraix= listfr.get(i) ;
				
			}
			}  
		return fraix;
	}


	@Override
	public MessageReponse modifier(fraispayement fraix) {
		// TODO Auto-generated method stub
		fraispayement metiers = fraixrepoistory.findById(fraix.getIdfraix()).orElse(null) ;
		fraix.setFormateur(metiers.getFormateur());
		fraix.setSession(metiers.getSession());
		if(metiers== null) {
		return new MessageReponse(false, "erreur , formation  introuvable");
		}
		fraixrepoistory.save(fraix);
		return new MessageReponse(true, "operation modifier effectue avec succes");
	}


	@Override
	public List<Session> getsessionfromateur(long idformateur) {
		// TODO Auto-generated method stub
		List<Session> listsession =new ArrayList<Session>() ;
		List<fraispayement> listfr = fraixrepoistory.findAll() ;
		for(int i=0 ;i<listfr.size() ;i++)
		{
			if(listfr.get(i).getFormateur().getId()==idformateur )
			{
				listsession.add(listfr.get(i).getSession());
				
				
			}
			}  
		return listsession;
	}

}
