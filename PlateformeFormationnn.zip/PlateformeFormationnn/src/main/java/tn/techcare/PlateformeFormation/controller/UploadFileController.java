package tn.techcare.PlateformeFormation.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import tn.techcare.PlateformeFormation.model.CV;
import tn.techcare.PlateformeFormation.model.Certificat;
import tn.techcare.PlateformeFormation.model.FileModel;
import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.specialiite;
import tn.techcare.PlateformeFormation.repository.CVRepository;
import tn.techcare.PlateformeFormation.repository.CertificatRepository;
import tn.techcare.PlateformeFormation.repository.FileRepository;
import tn.techcare.PlateformeFormation.repository.FormateurRepository;
import tn.techcare.PlateformeFormation.repository.SpecialiteRepository;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class UploadFileController {
	@Autowired
	  FileRepository fileRepository;
	@Autowired
	  CVRepository CvRepository;
	@Autowired
	  FormateurRepository formateurRepository;
	
	@Autowired
	   CertificatRepository CertificatRepository;
		 
		
		@Autowired
		SpecialiteRepository specialiteRepository;
	
	 
	    /*
	     * MultipartFile Upload
	     */
	    @PostMapping("/api/file/upload")
	    public String uploadMultipartFile(@RequestBody  MultipartFile file) {
	      try {
	        // save file to PostgreSQL
	        FileModel filemode = new FileModel(file.getOriginalFilename(), file.getContentType(), file.getBytes());
	        fileRepository.save(filemode);
	        return "File uploaded successfully! -> filename = " + file.getOriginalFilename();
	    } catch (  Exception e) {
	      return "FAIL! Maybe You had uploaded the file before or the file's size > 500KB";
	    }    
	    }
	    
	    
	     
	    
	    @PostMapping("/api/file/uploadcv/{idCategory}")
	    public String uploadMultipartFile(@RequestBody  MultipartFile file ,@PathVariable("idCategory") long idformateur) throws IOException {
	   
	    	  List<CV> cvs = CvRepository.findAll() ;
	    	  for(int i=0 ;i<cvs.size() ;i++)
	    	  {if(cvs.get(i).getFormateur().getId()==idformateur)
	    		  
	    	  {
	    		
	    		  CvRepository.delete(cvs.get(i));
	    	  }else
	    	  {
	          // save file to PostgreSQL
	        CV filemode = new CV(file.getOriginalFilename(), file.getContentType(), file.getBytes());
	   Optional<Formateur> f=formateurRepository.findById(idformateur) ;
	        filemode.setFormateur(f.get());
	        CvRepository.save(filemode);
	        return "File uploaded successfully! -> filename = " + file.getOriginalFilename();
	       
	    	  }}
	    	return " " ;
	   }
	      
	    
	    
	    
	      
	    @PostMapping("/api/file/uploadcertificat/{idCategory}/{idsp}")
	    public String uploadMultipartFile(@RequestBody  MultipartFile file ,@PathVariable("idCategory") long idformateur ,@PathVariable("idsp") long idspecialite) {
	      try {
	        // save file to PostgreSQL
	        Certificat filemode = new Certificat(file.getOriginalFilename(), file.getContentType(), file.getBytes());
	       Optional<Formateur> f=formateurRepository.findById(idformateur) ;
	       List<specialiite> specialite= (List<specialiite>) f.get().getSpecialites();
	      for(int i=0 ;i<specialite.size();i++)
	      { if(specialite.get(i).getIdspecialite()==idspecialite)
	      {  	        CertificatRepository.save(filemode);

	    	  specialite.get(i).getCertificats().add(filemode);
	    	  
	      }
	      }
	           return "File uploaded successfully! -> filename = " + file.getOriginalFilename();
	    } catch (  Exception e) {
	      return "FAIL! Maybe You had uploaded the file before or the file's size > 500KB";
	    }    
	    }
	    
	    
}
