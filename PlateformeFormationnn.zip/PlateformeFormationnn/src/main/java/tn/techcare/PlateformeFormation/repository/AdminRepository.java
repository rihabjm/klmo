package tn.techcare.PlateformeFormation.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import tn.techcare.PlateformeFormation.model.Admin;

public interface AdminRepository extends JpaRepository<Admin, Integer> {
	List<Admin> findByLogin(String email);
	List<Admin > findByLoginAndId(String email,int id);


}
