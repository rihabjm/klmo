package tn.techcare.PlateformeFormation.controller;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import tn.techcare.PlateformeFormation.model.Inscrir;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Salle;
import tn.techcare.PlateformeFormation.model.Seance;
import tn.techcare.PlateformeFormation.model.Session;
import tn.techcare.PlateformeFormation.service.SeanceService;
import tn.techcare.PlateformeFormation.repository.SeanceRepository;

@CrossOrigin("*")
@RestController
@RequestMapping("/Seance")
public class SeanceConroller {

	@Autowired
	private  SeanceService seanceservice ;
	
	@Autowired
	private  SeanceRepository SeanceRepository ;
	
	
	
	
	@GetMapping("/seancebyidsession/{id}")
	private  List<Seance> getseance(@PathVariable("id")Long  idsession) {
		return seanceservice.getAllSeancebysession(idsession) ;
	
	}

	@GetMapping("/get")
	public List<Seance>getAllSeance()
	{
		
     return SeanceRepository.findAll();
		   
	}
	
	
	@PutMapping("/update")
	private MessageReponse updateformation (@RequestBody Seance  senace ) {
		return seanceservice.ModifierSeance(senace) ;
		
	}

	@DeleteMapping("{id}")
	private MessageReponse deletSession (@PathVariable("id") Long id) {
		return seanceservice.SupprimerSession(id);
		
	}
	
	
}
