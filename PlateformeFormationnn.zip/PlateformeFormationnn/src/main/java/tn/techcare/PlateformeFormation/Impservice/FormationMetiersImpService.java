package tn.techcare.PlateformeFormation.Impservice;

import java.util.ArrayList;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.repository.FormateurRepository;
import tn.techcare.PlateformeFormation.repository.FormationMetiersRepository;
import tn.techcare.PlateformeFormation.service.FormationMetiersService;

@Service
@Transactional
public class FormationMetiersImpService implements FormationMetiersService {
	@Autowired
	private FormationMetiersRepository formationmetiersRepository ;

	@Autowired
	private FormateurRepository formateurrepository ;
	 
	@Transactional
	@Override
	public FormationMetiers   ajoutFormation(FormationMetiers formation) {
	 
		formationmetiersRepository.save(formation);
		return formation ;
	}

	@Override
	public List<FormationMetiers> getAllFormation() {
		
		
	return formationmetiersRepository.findAll();
	}
	@Transactional
	@Override
	public MessageReponse updateFormation(FormationMetiers formation) {
		FormationMetiers metiers = formationmetiersRepository.findById(formation.getIdformation()).orElse(null) ;
		if(metiers== null) {
		return new MessageReponse(false, "erreur , formation  introuvable");
		}
		formationmetiersRepository.save(formation);
		return new MessageReponse(true, "operation modifier effectue avec succes");
	}

	
	@Transactional
	@Override
	public MessageReponse supprimerFormation(Long id) {
		FormationMetiers metiers = formationmetiersRepository.findById(id).orElse(null) ;
		if(metiers== null) {
		return new MessageReponse(false, "erreur , formation  introuvable");
		}
		formationmetiersRepository.delete(metiers);
		return new MessageReponse(true, "operation delet effectue avec succes");
	}

	@Override
	public List<FormationMetiers> getformationbytype(String type) {
		// TODO Auto-generated method stub
		
	     List<FormationMetiers> list =new ArrayList(); 
	     list =formationmetiersRepository.findFormationMetiersByType(type);
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
		
		
	}



	@Override
	public List<FormationMetiers> getformationbyintitule(String intitule) {
      List<FormationMetiers> list =new ArrayList(); 
	     list =formationmetiersRepository.findFormationMetiersByIntitule(intitule);
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
	}




	@Override
	public List<FormationMetiers> getformationbyPrix(float prix) {
	
		   List<FormationMetiers> list =new ArrayList(); 
		     list =formationmetiersRepository.findFormationMetiersByPrix(prix) ;
			
			if (list ==null ) {
				System.out.println("");

			}
			return list ;
		
		
	}

	@Override
	public FormationMetiers getformationbyId(Long id) {
		// TODO Auto-generated method stub
		return formationmetiersRepository.findFormationMetiersByIdformation(id) ;
	}
   



	}
