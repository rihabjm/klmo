package tn.techcare.PlateformeFormation.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import tn.techcare.PlateformeFormation.model.Utilisateur;
import tn.techcare.PlateformeFormation.repository.UtilisateurRepository;
import tn.techcare.PlateformeFormation.service.AccountService;
import tn.techcare.PlateformeFormation.service.UtilisateurService;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;


@CrossOrigin("*")
@RestController
@RequestMapping("/utilisateur")
public class UtilisateurController {
	 @Autowired
	    private AccountService accountService;
	    @Autowired
	    private UtilisateurService userService ;
	    @Autowired
	    private UtilisateurRepository userrepository ;

	    @GetMapping("/list")
	    public List<Utilisateur> getAllUsers(){
	        return userService.getAllUsers();
	    }



	    @PostMapping("/register")
	    public Utilisateur addUser(@RequestBody Utilisateur user){
	        return accountService.saveUser(user);
	    }
	    
	    @PostMapping("/registerformateur")
	    public Utilisateur addUserformateur(@RequestBody Utilisateur user){
	        return accountService.saveUserFormateur(user);
	    }
	    
	    @PostMapping("/registergestionnaire")
	    public Utilisateur addUsergestionnaire(@RequestBody Utilisateur user){
	        return accountService.saveUsergestionnaire(user);
	    }
	    
	    @PostMapping("/registerpatrticipant")
	    public Utilisateur addUserparticipant(@RequestBody Utilisateur user){
	        return accountService.saveUserParticipant(user);
	    }
	    @GetMapping("/user/{id}")
	    public Utilisateur getUserById(@PathVariable("id") long id){
	        return userService.getUserById(id);
	    }
	    
	    @GetMapping("/byid/{id}")
	    public Optional<Utilisateur> getById(@PathVariable("id") long id){
	        return userrepository.findById(id) ;
	    }
	    @PutMapping("/update/{id}")
	    public void updateUser(@Valid @RequestBody Utilisateur user, @PathVariable("id") long id){
	        userService.updateUser(user, id);
	    }
	    @DeleteMapping("/delete/{id}")
	    public void deleteUser(@PathVariable("id") long id){
	        userService.deleteUser(id);
	    }
	    @GetMapping("/user/listUsers")
	    public List<Utilisateur> getTypeUsers(){
	        return userService.getTypeUsers("USER");
	    }
	    @PostMapping("/addAdmin")
	    public Utilisateur addAdmin(@RequestBody Utilisateur user){
	        return null;
	    }

	    @GetMapping("/usermail/{email}")
	    public Utilisateur getUserByEmail(@PathVariable("email") String email){
	        return userService.findByEmail(email);
	    }



}
