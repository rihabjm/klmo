package tn.techcare.PlateformeFormation.Impservice;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.specialiite;
import tn.techcare.PlateformeFormation.repository.SessionRepository;
import tn.techcare.PlateformeFormation.repository.SpecialiteRepository;
import tn.techcare.PlateformeFormation.service.SpecialiteService;
@Service
@Transactional
public class SpecialiteImpservice implements SpecialiteService  {

	@Autowired
	private SpecialiteRepository  specialiterepoistory;
	
	
	@Override
	public MessageReponse AjouterSpecialite(specialiite specialite) {
		// TODO Auto-generated method stub
		specialiterepoistory.save(specialite) ;
		   return new MessageReponse(true, specialite.getIdspecialite()+ "specialit�  est ajouter ") ;	}


	@Override
	public List<specialiite> getAllSpecilite() {
		// TODO Auto-generated method stub
		return specialiterepoistory.findAll();
	}


	@Override
	public specialiite getspecialiteById(long id) {
		// TODO Auto-generated method stub
		return specialiterepoistory.findByIdspecialite(id)	;
		}


	@Override
	public List<specialiite> getSpeciliteByformateur(long id) {
	
		 return null ;
		
		}

	@JsonIgnore
	@Override
	public List<Formateur> getcategorieFormation(String categorie) {
		// TODO Auto-generated method stub
		List<Formateur> formateurs =new ArrayList<Formateur>();
		List<specialiite> spc =specialiterepoistory.findAll() ;
		for(int i=0 ;i<spc.size();i++)
		{   if(spc.get(i).getNomspecialite().equals(categorie))
			
		{
			formateurs=(List<Formateur>) spc.get(i).getFormateurs() ;
		}}
	
		return formateurs;	}

	

}
