package tn.techcare.PlateformeFormation.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import tn.techcare.PlateformeFormation.model.Session;
@Repository
public interface SessionRepository extends JpaRepository<Session,Long> {
	Session findSessionByIdsession(Long id ) ;
   List<Session> findSessionByFormation(Long idformation) ;
}
