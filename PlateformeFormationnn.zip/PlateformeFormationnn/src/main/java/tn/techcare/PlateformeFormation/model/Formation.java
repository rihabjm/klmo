package tn.techcare.PlateformeFormation.model;


import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
@Table(name = "formation")
public class Formation {

	@Id
	 @Column(name = "idformation", nullable = false, insertable = true, updatable = true)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idformation;
	private String intitule ;
	private float prix ;
	private String type ;
    private String description ;
    private String categorie ;

    

    
    
  
	public String getCategorie() {
		return categorie;
	}

	public void setCategorie(String categorie) {
		this.categorie = categorie;
	}

	
   
	@JsonIgnore
	@OneToMany(mappedBy = "formation", cascade = {CascadeType.ALL})
	private List<Session> session ;

	public Long getIdformation() {
		return idformation;
	}

	public void setIdformation(Long idformation) {
		this.idformation = idformation;
	}

	public String getIntitule() {
		return intitule;
	}

	public void setIntitule(String intitule) {
		this.intitule = intitule;
	}


	public float getPrix() {
		return prix;
	}

	public void setPrix(float prix) {
		this.prix = prix;
	}
	



	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}


  public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

 

	public List<Session> getSession() {
		return session;
	}

	public void setSession(List<Session> session) {
		this.session = session;
	}

	
	 
}
