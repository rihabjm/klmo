package tn.techcare.PlateformeFormation.Impservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.CV;
import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.repository.CVRepository;
import tn.techcare.PlateformeFormation.repository.FormateurRepository;
import tn.techcare.PlateformeFormation.service.CVService;
@Service
public class CVImpService implements CVService {
	@Autowired
	private FormateurRepository  formateurrepoistory;
	
	@Autowired   
	private CVRepository  imagerepoistory;
	@Override
	public CV uploadimageFormateur(CV cv, long idformateur) {
		// TODO Auto-generated method stub
		 Formateur formateur = formateurrepoistory.findFormateurById(idformateur);
         cv.setFormateur(formateur);	  
	        return imagerepoistory.save(cv);	}

}
