package tn.techcare.PlateformeFormation.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import tn.techcare.PlateformeFormation.model.CV;

public interface CVRepository extends JpaRepository<CV, Long>  {
    Optional<CV> findByName(String name);

}
