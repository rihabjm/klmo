package tn.techcare.PlateformeFormation.model;

import java.io.Serializable;
import java.sql.Date;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;


import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;


import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@Table(name = "utilisateur")
public class Utilisateur implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private Long id ;
	 private String nom ;
	 private String prenom ;
	 private String adresse ;
	 private int telephone ;
	 private String login ;
	 private String mdp ;
	 private Date dateNAisse ; 
	 private String sexe ;
	 private String gmail ;
	 private String facebook ;
	 private String linked ;
	 @JsonIgnore
	    @ManyToOne(cascade = CascadeType.MERGE)
	    @JoinColumn(name = "idutilisateur")
	    private Role role  ;



	public String getLogin() {
			return login;
		}
		public void setLogin(String login) {
			this.login = login;
		}
		public String getMdp() {
			return mdp;
		}
		public void setMdp(String mdp) {
			this.mdp = mdp;
		}
		public String getGmail() {
			return gmail;
		}
		public void setGmail(String gmail) {
			this.gmail = gmail;
		}
		public String getFacebook() {
			return facebook;
		}
		public void setFacebook(String facebook) {
			this.facebook = facebook;
		}
		public String getLinked() {
			return linked;
		}
		public void setLinked(String linked) {
			this.linked = linked;
		}

  
	public Date getDateNAisse() {
		return dateNAisse;
	}
	public void setDateNAisse(Date dateNAisse) {
		this.dateNAisse = dateNAisse;
	}
 

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public int getTelephone() {
		return telephone;
	}
	public void setTelephone(int telephone) {
		this.telephone = telephone;
	}

	public String getSexe() {
		return sexe;
	}
	public void setSexe(String sexe) {
		this.sexe = sexe;
	}
	
	


	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public Utilisateur(Long id, String nom, String prenom, String adresse, int telephone, String login, String mdp,
			Date dateNAisse, String sexe, String gmail, String facebook, String linked) {
		super();
		this.id = id;
		this.nom = nom;
		this.prenom = prenom;
		this.adresse = adresse;
		this.telephone = telephone;
		this.login = login;
		this.mdp = mdp;
		this.dateNAisse = dateNAisse;
		this.sexe = sexe;
		this.gmail = gmail;
		this.facebook = facebook;
		this.linked = linked;	}
	public Utilisateur() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	 public Utilisateur(String login, String mdp) {
		super();
		this.login = login;
		this.mdp = mdp;
	}

	
	
	// TODO Auto-generated constructor stub
	}

	 
	 

