package tn.techcare.PlateformeFormation.Impservice;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Programmekhademni;
import tn.techcare.PlateformeFormation.repository.ProgrammekhademniRepository;
import tn.techcare.PlateformeFormation.service.ProgrammekhademniService;

@Service
public class ProgrammekhademniImpService  implements ProgrammekhademniService{
   
	@Autowired 
	ProgrammekhademniRepository programmerepository ;
	
	@Override
	public MessageReponse ajoutFormation(Programmekhademni formation) {
		programmerepository.save(formation);
		return  new MessageReponse(true, formation.getIdformation()+ "formation est ajouter ") ;
	}

	@Override
	public List<Programmekhademni> getAllFormation() {
		// TODO Auto-generated method stub
		return (List<Programmekhademni>) programmerepository.findAll();
	}

	@Override
	public List<Programmekhademni> getformationbyintitule(String intitule) {
		// TODO Auto-generated method stub
		return programmerepository.findProgrammekhademniByIntitule(intitule);
	}

	@Override
	public MessageReponse updateformation(Programmekhademni formation) {
		// TODO Auto-generated method stub
		Programmekhademni metiers = programmerepository.findById(formation.getIdformation()).orElse(null) ;
		if(metiers== null) {
		return new MessageReponse(false, "erreur , formation  introuvable");
		}
		programmerepository.save(formation);
		return new MessageReponse(true, "operation modifier effectue avec succes");	}

	@Override
	public Programmekhademni getformationbyId(Long id) {
		// TODO Auto-generated method stub
		return programmerepository.findProgrammekhademniByIdformation(id) ;
	}

	@Override
	public MessageReponse supprimerFormation(Long id) {
		// TODO Auto-generated method stub
		Programmekhademni metiers = programmerepository.findById(id).orElse(null) ;
		if(metiers== null) {
		return new MessageReponse(false, "erreur , formation  introuvable");
		}
		programmerepository.delete(metiers);
		return new MessageReponse(true, "operation delet effectue avec succes");	}

	@Override
	public List<Programmekhademni> getformationbytype(String type) {
		// TODO Auto-generated method stub
		return programmerepository.findProgrammekhademniByType(type);
	}


	@Override
	public List<Programmekhademni> getformationbyPrix(float prix) {
		// TODO Auto-generated method stub
		return programmerepository.findProgrammekhademnieByPrix(prix);
	}

}
