import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule , Routes } from '@angular/router';
import { FormsModule ,ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import {httpInterceptorProviders} from './Service/auth-interceptor';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { FooterComponent } from './footer/footer.component';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { HttpClientModule } from '@angular/common/http';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { AccplateformeComponent } from './accplateforme/accplateforme.component';
import { AjouterformateurComponent } from './view/formateur/ajouterformateur/ajouterformateur.component';
import { ModifierformateurComponent } from './view/formateur/modifierformateur/modifierformateur.component';
import { ListerformateurComponent } from './view/formateur/listerformateur/listerformateur.component';
import { CalendrierformateurComponent } from './view/formateur/calendrierformateur/calendrierformateur.component';
import { CalendrierformationComponent } from './view/formation/calendrierformation/calendrierformation.component';
import { ListerformationComponent } from './view/formation/listerformation/listerformation.component';
import { ListerformationmetiersComponent } from './view/formation/listerformationmetiers/listerformationmetiers.component';
import { ListerformationmoduleComponent } from './view/formation/listerformationmodule/listerformationmodule.component';
import { ListerprogrammekhdemniComponent } from './view/formation/listerprogrammekhdemni/listerprogrammekhdemni.component';

import { FullCalendarModule } from '@fullcalendar/angular'; // the main connector. must go first
import dayGridPlugin from '@fullcalendar/daygrid'; // a plugin
import interactionPlugin from '@fullcalendar/interaction';
import { OuvrirsessionComponent } from './view/formation/ouvrirsession/ouvrirsession.component';
import { PromotionComponent } from './view/formation/promotion/promotion.component';
import { ChoisirpromotionComponent } from './view/formation/choisirpromotion/choisirpromotion.component';
import { AffichesessionComponent } from './view/session/affichesession/affichesession.component';
import { SessionparformationComponent } from './view/session/sessionparformation/sessionparformation.component';
import { LoginComponent } from './view/loginregistre/login/login.component';
import { RegistreComponent } from './view/loginregistre/registre/registre.component';
import { ModifmdpComponent } from './view/loginregistre/modifmdp/modifmdp.component';
import { ModifprofilComponent } from './view/loginregistre/modifprofil/modifprofil.component';
import { AjoutsalleComponent } from './view/salle/ajoutsalle/ajoutsalle.component'; // a plugin
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
FullCalendarModule.registerPlugins([ // register FullCalendar plugins
  dayGridPlugin,
  interactionPlugin
]);

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    SidebarComponent,
    FooterComponent,
    AccplateformeComponent,
  AjouterformateurComponent,
    ModifierformateurComponent,
    ListerformateurComponent,
    CalendrierformateurComponent,
    CalendrierformationComponent,
    ListerformationComponent,
    ListerformationmetiersComponent,
    ListerformationmoduleComponent,
    ListerprogrammekhdemniComponent,
    OuvrirsessionComponent,
    PromotionComponent,
    ChoisirpromotionComponent,
    AffichesessionComponent,
    SessionparformationComponent,
OuvrirsessionComponent,
LoginComponent,
RegistreComponent,
ModifmdpComponent,
ModifprofilComponent,
AjoutsalleComponent
  ],
  imports: [
  FullCalendarModule ,// register FullCalendar with you app

    AppRoutingModule,
     BrowserModule,
    RouterModule,
    AppRoutingModule,
    FormsModule,
    NgbModule,

  ReactiveFormsModule ,HttpClientModule ,
   TooltipModule.forRoot(),NgMultiSelectDropDownModule.forRoot()

  ],
  providers: [httpInterceptorProviders ],
  bootstrap: [AppComponent],
 })
export class AppModule { }
