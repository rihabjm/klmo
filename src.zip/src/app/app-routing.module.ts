import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AccplateformeComponent } from './accplateforme/accplateforme.component';
import { AjouterformateurComponent } from './view/formateur/ajouterformateur/ajouterformateur.component';
import { ModifierformateurComponent } from './view/formateur/modifierformateur/modifierformateur.component';
import { ListerformateurComponent } from './view/formateur/listerformateur/listerformateur.component';
import { CalendrierformateurComponent } from './view/formateur/calendrierformateur/calendrierformateur.component';
import { CalendrierformationComponent } from './view/formation/calendrierformation/calendrierformation.component';
import { ListerformationComponent } from './view/formation/listerformation/listerformation.component';
import { ListerformationmetiersComponent } from './view/formation/listerformationmetiers/listerformationmetiers.component';
import { ListerformationmoduleComponent } from './view/formation/listerformationmodule/listerformationmodule.component';
import { ListerprogrammekhdemniComponent } from './view/formation/listerprogrammekhdemni/listerprogrammekhdemni.component';
import { OuvrirsessionComponent } from './view/formation/ouvrirsession/ouvrirsession.component';
import { PromotionComponent } from './view/formation/promotion/promotion.component';
import { ChoisirpromotionComponent } from './view/formation/choisirpromotion/choisirpromotion.component';
import { AffichesessionComponent } from './view/session/affichesession/affichesession.component';
import { SessionparformationComponent } from './view/session/sessionparformation/sessionparformation.component';
import { LoginComponent } from './view/loginregistre/login/login.component';
import { RegistreComponent } from './view/loginregistre/registre/registre.component';
import { ModifmdpComponent } from './view/loginregistre/modifmdp/modifmdp.component';
import { ModifprofilComponent } from './view/loginregistre/modifprofil/modifprofil.component';
import { AjoutsalleComponent } from './view/salle/ajoutsalle/ajoutsalle.component';


const routes: Routes = [

      { path: 'formateur/ajouter', component: AjouterformateurComponent },
      { path: 'formateur/modifier/:id', component: ModifierformateurComponent },
      { path: 'formateur/lister', component: ListerformateurComponent },
      { path: 'formateur/calendrier', component: CalendrierformateurComponent },
      { path: 'formation/listerformationparmetiers', component: ListerformationmetiersComponent },
      { path: 'formation/listerprogrammekhdemni', component: ListerprogrammekhdemniComponent },
     { path: 'formation/listerformationparmodule', component: ListerformationmoduleComponent },
    { path: 'formation/listerformation', component: ListerformationComponent },
        { path: 'formation/calendrierformation/:id', component: CalendrierformationComponent },
     { path: 'formation/ouvrirsession', component:OuvrirsessionComponent  },
           { path: 'session/affichesession/:id', component:AffichesessionComponent  },
       { path: 'formation/promotion', component:PromotionComponent  },
     //  { path: ':id', component:ChoisirpromotionComponent  },

          { path: 'session/affichesession', component: AffichesessionComponent} ,
            { path: ':id', component: SessionparformationComponent} ,

           { path: 'salle/ajoutersalle', component: AjoutsalleComponent} ,
                 { path: 'loginregistre/login', component: LoginComponent} ,
            { path: 'loginregistre/registre', component: RegistreComponent } ,
            { path: 'loginregistre/modifmdp', component: ModifmdpComponent } ,
            { path: 'loginregistre/modifprofil', component: ModifprofilComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],

  exports: [RouterModule]
})
export class AppRoutingModule { }
