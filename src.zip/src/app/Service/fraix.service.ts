import { Injectable } from '@angular/core';
import {Fraix} from '../Model/fraix';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class FraixService {

  private url = Config.BASE_URL + '/fraix';
  private urld = this.url + '/add';
private urldetail =this.url+'/byidsession' ;
private urldl =this.url+'/byformateursession' ;
  // tslint:disable-next-line:max-line-length
  // private header = new HttpHeaders({'authorization': 'bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1c2VyMUBnbWFpbCIsInJvbGVzIjpbIlVTRVIiXSwiaXNzIjoiL2xvZ2luIiwiZXhwIjoxNTc1NDg4Nzc5fQ.k8ZKAtZUaGXefvsTgqyku_pANq_sH5rbd2NV0xQxLFM'});
  constructor(private httpClient: HttpClient) { }

  add(fraix: object, idCategory: number,id : number): Observable<object> {
    return this.httpClient.post(`${this.urld}/${idCategory}/${id}`, fraix);
  }
  public getbysession(id: number): Observable<any> {
    return this.httpClient.get(`${this.urldetail}/${id}`);
  }

  public getbyFormateursession(id: number ,idsession): Observable<any> {
    return this.httpClient.get(`${this.urldl}/${id}/${idsession}`);
  }

 public update(fraix: object): Observable<any> {

  return this.httpClient.put(this.url+'/update' ,fraix);
  }

}
