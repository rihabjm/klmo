import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Session} from '../Model/Session';
import {Inscrir} from '../Model/Inscrir';
@Injectable({
  providedIn: 'root'
})
export class InscrirService {
constructor(private httpClient: HttpClient) { }

private url = Config.BASE_URL + '/inscrir';
private urld = this.url + '/products';
private urlinscrir  =Config.BASE_URL + '/inscrir/bysession'



  createProduct(product: object, idCategory: number): Observable<object> {
    return this.httpClient.post(`${this.urld}/${idCategory}`, product);
  }

  public getSessionParticipant(id: number): Observable<any> {
    return this.httpClient.get(`${this.urlinscrir}/${id}`);
  }

}
