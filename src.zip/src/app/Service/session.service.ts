import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Session} from '../Model/Session';
import {Inscrir} from '../Model/Inscrir';

@Injectable({
  providedIn: 'root'
})
export class SessionService {
  constructor(private httpClient: HttpClient) { }

private url = Config.BASE_URL + '/Session';
private urld = this.url + '/products';
private urld1 = this.url + '/addparticipant';
private urlinscrir = this.url + '/inscrirbyid';
private urldetail =Config.BASE_URL + '/Session/byid'
private urlformation =Config.BASE_URL + '/Session/byformation'
private urlintilue = this.url + '/byintituleformation';
private urlgetinscri=this.url+'/getinscrirbyid';

  createProduct(product: object, idCategory: number): Observable<any> {
    return this.httpClient.post(`${this.urld}/${idCategory}`, product);
  }

    addparticipant(participant: object, idCategory: number): Observable<object> {
    return this.httpClient.post(`${this.urld1}/${idCategory}`, participant);
  }


    public get(id: number): Observable<any> {
    return this.httpClient.get(`${this.urldetail }/${id}`);
  }
    public getSessionFormation(id: number): Observable<any> {
    return this.httpClient.get(`${this.urlformation }/${id}`);
  }

 public getintituleFormation(id: number): Observable<any> {
    return this.httpClient.get(`${this.urlintilue }/${id}`);
  }

    public getInscrir(id: number): Observable<any> {
    return this.httpClient.get(`${this.urlinscrir }/${id}`);
  }




public save(session :Session): Observable<any> {

  return this.httpClient.post(this.url+'/add',session );
  }

  public  getAll(): Observable<Session[]> {
    return this.httpClient.get<Session[]>(this.url+'/get');
  }

 public  getAllplanifier(): Observable<Session[]> {
    return this.httpClient.get<Session[]>(this.url+'/getsessionplanifier');
  }

 public updateinscrir(inscrir :Inscrir): Observable<any> {

  return this.httpClient.put(this.url+'//updateinscrirsession' ,inscrir);
  }


   public deleteinscrir(idsession:number , idinscrir): Observable<any> {
    return this.httpClient.delete(this.url + '/' + idsession+'/'+idinscrir);
  }

   public getinscrirbyid(idinscrir: number): Observable<any> {
    return this.httpClient.get(`${this.urlgetinscri }/${idinscrir}`);
  }



}
