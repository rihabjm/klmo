import { Salle} from './Salle';
import { Seance} from './Seance';
import { Session} from './Session';
export class Planing {
  idplaning :number ;
  date : Date  ;
salle :Salle ;
seance :Seance ;
Session :Session  ;
}

