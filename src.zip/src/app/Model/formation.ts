import {Observable} from 'rxjs';
export class Formation {
idformation:number ;
intitule : String ;
prix :String ;
type: String ;
categorie: String ;
description: String ;
}
