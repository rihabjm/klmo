import{Formateur } from './formateur' ;
import{Session } from './session' ;
export class Fraix {
idfraix :number ;
avance : number ;
nombreheure :number  ;
	salaire : number  ;
	formateur :Formateur ;
	session :Session

}
