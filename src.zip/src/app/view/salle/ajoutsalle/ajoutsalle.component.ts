import { Component, OnInit } from '@angular/core';
import {Salle} from '../../../Model/Salle';
import {SalleService} from '../../../Service/salle.service';

@Component({
  selector: 'app-ajoutsalle',
  templateUrl: './ajoutsalle.component.html',
  styleUrls: ['./ajoutsalle.component.scss']
})
export class AjoutsalleComponent implements OnInit {
salle :Salle =new Salle();
listesalle : Salle[] = new Array();
  constructor( private salleservice :SalleService) { }

  ngOnInit() { this.getsalle();
  }
ajoutersalle(){
this.salleservice.save(this.salle).subscribe(data => {


 this.getsalle();
        console.log(data)
      }, error => console.log(error));


}


getsalle(){
this.salleservice.getAll().subscribe(data => {
   this.listesalle =data ;

        console.log(data)
      }, error => console.log(error));
}
}
