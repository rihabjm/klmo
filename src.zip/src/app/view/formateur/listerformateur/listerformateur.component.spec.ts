import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListerformateurComponent } from './listerformateur.component';

describe('ListerformateurComponent', () => {
  let component: ListerformateurComponent;
  let fixture: ComponentFixture<ListerformateurComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListerformateurComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListerformateurComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
