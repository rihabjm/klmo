import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListerformationComponent } from './listerformation.component';

describe('ListerformationComponent', () => {
  let component: ListerformationComponent;
  let fixture: ComponentFixture<ListerformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListerformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListerformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
