import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListerformationmoduleComponent } from './listerformationmodule.component';

describe('ListerformationmoduleComponent', () => {
  let component: ListerformationmoduleComponent;
  let fixture: ComponentFixture<ListerformationmoduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListerformationmoduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListerformationmoduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
